#ifndef _shrink_h_INCLUDED
#define _shrink_h_INCLUDED

struct kissat;

void kissat_shrink_clause (struct kissat *);

#endif
