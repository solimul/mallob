
bool kissat_importing_redundant_clauses (kissat * solver);
void kissat_import_redundant_clauses (kissat * solver);
